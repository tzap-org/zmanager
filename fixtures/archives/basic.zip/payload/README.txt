Z-Manager fixture payload
